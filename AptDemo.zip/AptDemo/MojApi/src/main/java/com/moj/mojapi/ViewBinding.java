package com.moj.mojapi;

/**
 * @author : moj
 * @date : 2019/6/24
 * @description :
 */
public interface ViewBinding {
    void bindView();
}
